/*
Task: write a short program that uses a for loop to write the numbers 1 through 10 to a file
*/

#include <iostream>
#include <fstream>
using namespace std;

int main()
{
	//opens file
	ofstream outputFile;
	outputFile.open("5.23.txt");

	cout << "Here are the numbers that will be recorded and saved into file.";

	for (int number = 1; number < 11; number++)
		//records the numbers into file
		outputFile << number << endl;

	cout << "\nDone";

	//closes file
	outputFile.close();

	return 0;
}